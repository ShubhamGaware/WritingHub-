from django.apps import AppConfig


class BlogapplicationConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'BlogApplication'
